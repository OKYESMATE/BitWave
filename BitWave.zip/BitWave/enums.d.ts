// Auto-generated. Do not edit.
declare namespace record {
}

// Auto-generated. Do not edit. Really.
