
> Open this page at [https://martinwork.github.io/pxt-audio-recording/](https://martinwork.github.io/pxt-audio-recording/)

IMPORTANT: See [this issue](https://github.com/microsoft/pxt-microbit/issues/5944#issuecomment-2360923272)

## Use as Extension

This is an experiment. Please don't use this repo directly.

This repository can be added as an **extension** in MakeCode.

* open [https://makecode.microbit.org/](https://makecode.microbit.org/)
* click on **New Project**
* click on **Extensions** under the gearwheel menu
* search for **https://github.com/martinwork/pxt-audio-recording** and import

## Edit this project

To edit this repository in MakeCode.

* open [https://makecode.microbit.org/](https://makecode.microbit.org/)
* click on **Import** then click on **Import URL**
* paste **https://github.com/martinwork/pxt-audio-recording** and click import

#### Metadata (used for search, rendering)

* for PXT/microbit
<script src="https://makecode.com/gh-pages-embed.js"></script><script>makeCodeRender("{{ site.makecode.home_url }}", "{{ site.github.owner_name }}/{{ site.github.repository_name }}");</script>
